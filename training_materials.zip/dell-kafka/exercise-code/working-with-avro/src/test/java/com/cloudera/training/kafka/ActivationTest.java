/**
 * Copyright (C) Cloudera, Inc. 2019
 */
package com.cloudera.training.kafka;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

//import com.cloudera.training.kafka.data.Activation;

public class ActivationTest {


	@Test
	public void testActivation() {
  /*          
            long timestamp = System.currentTimeMillis();
            int customerId = 200001;
            String deviceId = "BC7F05D2";
            String model = "Samsung Galaxy S9";
            String phoneNumber = "415-555-6841";
            Activation activation = new Activation(timestamp, customerId, deviceId, phoneNumber, model);

            assertEquals("Timestamp did not match", timestamp, activation.getTimestamp().longValue());
            assertEquals("Customer ID did not match", customerId, activation.getCustomerId().intValue());
            assertEquals("Device ID did not match", deviceId, activation.getDeviceId());
            assertEquals("Device Model did not match", model, activation.getModel());
            assertEquals("Phone Number did not match", phoneNumber, activation.getPhoneNumber());
	*/
	}

}
